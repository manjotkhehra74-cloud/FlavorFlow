Upload archive to the existing VM home folder. Run:
cd ~
tar -xzf flavorflow-support-release.tar.gz
sudo bash flavorflow-support-release/tools/ff-support-publish.sh "$HOME/flavorflow-support-release/web-landing"

Publishes homepage/support with backups. Does not provision chat/email.
